<div name='footer-default'>© 2015 台灣電力公司 版權所有</div>
<div name='footer-pagger' style='display:none'>
    <span class="btn btn-primary" name="btnPrepage">
        <i class="glyphicon glyphicon-chevron-left" data-position="left"></i>
    </span>
    <span class="paging-container">第&nbsp;
        <div class="dropup btn-group">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                <span name="currpage" class="dropdown-label">0 / 0</span> <span class="caret"></span>
            </a>
            <ul name="pagingmenu" class="dropdown-menu scroll-menu"></ul>
        </div>&nbsp;頁，共&nbsp;
        <span id="rowcount">0</span>&nbsp;筆
    </span>
    <span class="btn btn-primary" name="btnNextpage">
        <i class="glyphicon glyphicon-chevron-right" data-position="right"></i>
    </span>
</div>
