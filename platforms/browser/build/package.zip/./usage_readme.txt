var allparams = $.url.paramAll();

var singleParam = $.url.param("aParamName");
