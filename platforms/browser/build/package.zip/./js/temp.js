var qs = new Querystring();
var tempor = qs.get("sid");

function temp(){
document.getElementById("dtp_input10").value = tempor;
}